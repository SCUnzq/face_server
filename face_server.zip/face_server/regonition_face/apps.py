from django.apps import AppConfig


class RegonitionFaceConfig(AppConfig):
    name = 'regonition_face'

import os
import face_recognition
import pymongo
import numpy as np

class my_face(object):
    known_facespath = 'media/known'
    baseface_titles = []
    baseface_face_encodings = []

def compare(image_name):
    # 人脸检测,并获取输入图像中所有人脸编码
    image = face_recognition.load_image_file(image_name)
    face_locations = face_recognition.face_locations(image)
    face_encodings = face_recognition.face_encodings(image, face_locations)
    name = []
    client = pymongo.MongoClient('localhost', 27017)
    faces = client['faces']
    sheet = faces['faces_sheet']
    for face_encoding in face_encodings:
        min = 5
        for item in sheet.find():
            distance = face_recognition.face_distance([np.array(item['encoding'])], face_encoding)[0]
            if distance<min:
                min = distance
                min_item = item
        if min<=0.5:
            name.append(min_item['name'])
        else:
            name.append('unknown')
        print(min)
    print(name)
    return name

def face_init():
    client = pymongo.MongoClient('localhost', 27017)
    faces = client['faces']
    sheet = faces['faces_sheet']
    for fn in os.listdir(my_face.known_facespath):  # fn 人脸文件名
        name = fn[:(len(fn) - 4)]
        if sheet.find_one({'name': name}) is None:
            encoding=face_recognition.face_encodings(face_recognition.load_image_file(my_face.known_facespath + "/" + fn))[0]
            data={
                'name':name,
                'encoding':encoding.tolist()
            }
            sheet.insert_one(data)
            print(name)

def register_face(filename):
    client = pymongo.MongoClient('localhost', 27017)
    faces = client['faces']
    sheet = faces['faces_sheet']
    name = filename[:(len(filename) - 4)]
    if sheet.find_one({'name': name}) is None:
        encoding = face_recognition.face_encodings(face_recognition.load_image_file(my_face.known_facespath + "/" + filename))[0]
        data = {
            'name': name,
            'encoding':encoding.tolist()
        }
        sheet.insert_one(data)
        print(name+"注册成功！")
        return name+"注册成功！"
    else:
        return name+"已经注册了!"

if __name__ == '__main__':
    image = 'C:/Users/nzq/Desktop/un.jpg'
    face_init()
    compare(image)
import os
from django.http import HttpResponse
from django.shortcuts import render
from regonition_face.face_recogn import compare, register_face


def index(request):
    return render(request, 'upload.html')

def recognition(request):
    if request.method == "POST":
        myFile = request.FILES.get("recognition_photo", None)
        if not myFile:
            return HttpResponse("没有选择文件!")
        s=handle_recognition(myFile, str(myFile))
        return HttpResponse(s)  # 此处简单返回一个成功的消息，在实际应用中可以返回到指定的页面中
    return HttpResponse("请用POST方法提交表单！")

def register(request):
    if request.method == "POST":
        myFile = request.FILES.get("register_photo", None)
        if not myFile:
            return HttpResponse("没有选择文件!")
        s=handle_register(myFile, str(myFile))
        return HttpResponse(s)  # 此处简单返回一个成功的消息，在实际应用中可以返回到指定的页面中
    return HttpResponse("请用POST方法提交表单！")

def handle_register(file,filename):
    path='media/known/'     # 上传文件的保存路径，可以自己指定任意的路径
    if not os.path.exists(path):
        os.makedirs(path)
    if not os.path.exists(path+filename):
        with open(path+filename,'wb+')as destination:
            for chunk in file.chunks():
                destination.write(chunk)
    return register_face(filename)

def handle_recognition(file,filename):
    path='media/unknown/'     # 上传文件的保存路径，可以自己指定任意的路径
    if not os.path.exists(path):
        os.makedirs(path)
    with open(path+filename,'wb+')as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    return compare(path+filename)